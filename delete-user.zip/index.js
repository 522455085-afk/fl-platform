/**
 * delete-user — privileged hard-delete of the current user.
 *
 * What this does (in order):
 *  1. Read the caller's uid from CloudBase context
 *  2. Refuse if the caller still owns any custom servers (defense in depth;
 *     the client also checks, but this is the authoritative gate)
 *  3. Remove every row in our user-scoped collections owned by this uid:
 *       profiles, server_members, dm_threads, dm_messages, message_reactions,
 *       presence
 *  4. Try to remove the CloudBase auth row itself via the admin API. The
 *     exact endpoint depends on the SDK version available in the runtime —
 *     we attempt the v2 surface first and fall back gracefully so the
 *     function still succeeds even if the admin call isn't supported in
 *     this environment.
 *  5. Return { ok: true }
 *
 * Safety:
 *  - Runs with cloud function privileges (service-role-equivalent), so DB
 *    writes bypass row-level security. Make sure the calling user can only
 *    target their own data — we hard-pin every query to `context.userInfo.uid`.
 *
 * Deployment: see DEPLOY_DELETE_USER_FUNCTION.md in the repo root.
 */

"use strict";

const tcb = require("@cloudbase/node-sdk");
const app = tcb.init({
  env: tcb.SYMBOL_CURRENT_ENV,
});
const db = app.database();
const _ = db.command;
const auth = app.auth();

/**
 * Best-effort delete every row in `collection` matching `where`.
 * Swallows errors so a single failing collection doesn't abort the whole
 *注销 — the user will still get their auth row removed, which is the
 * point.
 */
async function safeDelete(collection, where) {
  try {
    const res = await db.collection(collection).where(where).remove();
    return res?.deleted || 0;
  } catch (e) {
    console.warn(`[delete-user] ${collection} delete failed:`, e && e.message);
    return 0;
  }
}

exports.main = async (event, context) => {
  // CloudBase exposes the calling user's identity in different shapes
  // depending on SDK version / auth backend. Try every known surface
  // and log the full context shape so we can see what's actually there
  // when none of them work.
  const userInfo = (context && context.userInfo) || {};
  const auth = (context && context.auth) || {};
  const uid =
    userInfo.uid ||
    userInfo.openId ||
    userInfo.userId ||
    userInfo.customUserId ||
    auth.uid ||
    auth.openId ||
    (event && event.userInfo && event.userInfo.uid) ||
    null;

  console.log("[delete-user] context.userInfo:", JSON.stringify(userInfo));
  console.log("[delete-user] context.auth:", JSON.stringify(auth));
  console.log("[delete-user] resolved uid:", uid);

  if (!uid) {
    return {
      ok: false,
      error: "云函数无法识别调用者身份。userInfo / auth 字段都为空。",
      debug: { userInfo, auth, eventKeys: Object.keys(event || {}) },
    };
  }

  // ---- Pre-flight: refuse if caller owns servers ----
  try {
    const owned = await db
      .collection("servers")
      .where({ creator_id: uid })
      .limit(1)
      .get();
    if ((owned.data || []).length > 0) {
      return {
        ok: false,
        error:
          "你仍是一个或多个服务器的创始人。请先转让创始人或解散服务器后再注销。",
      };
    }
  } catch (e) {
    // Non-fatal — proceed.
    console.warn("[delete-user] owned-server check failed:", e && e.message);
  }

  // ---- Cleanup user-scoped data ----
  const counts = {
    profiles: await safeDelete("profiles", { id: uid }),
    server_members: await safeDelete("server_members", { user_id: uid }),
    dm_threads: await safeDelete("dm_threads", { user_id: uid }),
    dm_messages: await safeDelete("dm_messages", { author_id: uid }),
    message_reactions: await safeDelete("message_reactions", { user_id: uid }),
    presence: await safeDelete("presence", { presence_key: uid }),
  };

  // ---- Try to drop the CloudBase auth row ----
  // The admin auth API surface varies between SDK versions. We try a few
  // shapes; whichever one resolves wins. If none do, we still return ok
  // because the data has been wiped — the auth row will need a manual or
  // scheduled sweep.
  let authDeleted = false;
  const tryDeleteUid = async (fn) => {
    try {
      await fn();
      authDeleted = true;
    } catch (e) {
      // ignore; try the next shape
      console.warn("[delete-user] auth delete attempt failed:", e && e.message);
    }
  };

  if (typeof auth.deleteUser === "function") {
    await tryDeleteUid(() => auth.deleteUser(uid));
  }
  if (!authDeleted && typeof auth.getUserManagement === "function") {
    try {
      const mgr = auth.getUserManagement();
      if (mgr && typeof mgr.deleteUser === "function") {
        await tryDeleteUid(() => mgr.deleteUser(uid));
      }
    } catch (e) {
      console.warn("[delete-user] userManagement init failed:", e && e.message);
    }
  }
  if (!authDeleted && typeof app.callWxOpenApi === "function") {
    // Last-ditch: the WeChat-style open API can sometimes proxy auth ops.
    // Best-effort only.
    console.warn(
      "[delete-user] auth.deleteUser unsupported in this SDK; auth row preserved",
    );
  }

  return {
    ok: true,
    counts,
    authDeleted,
    note: authDeleted
      ? undefined
      : "Auth 凭证未删除（云函数 SDK 不支持本环境）。请联系管理员手动清理或升级 @cloudbase/node-sdk。",
  };
};
